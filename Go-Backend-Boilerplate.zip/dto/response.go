package dto

type HistoryResponse struct {
	HistoryId int     `json:"history_id"`
	Country   string  `json:"country"`
	Value     float64 `json:"value"`
}
