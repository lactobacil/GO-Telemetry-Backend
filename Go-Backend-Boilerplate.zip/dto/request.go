package dto

type InputHistory struct {
	Country string  `json:"country" binding:"required"`
	Value   float64 `json:"value" binding:"required,min=8"`
}

type DeleteRequest struct {
	NumberId float64 `json:"number_id" binding:"required"`
}

type NoteDeleteRequest struct {
	NoteID int `json:"note_id" binding:"required"`
}

type LoginRequest struct {
	UserId float64 `json:"user_id" binding:"required"`
}

type InputNotes struct {
	Title    string `json:"title" binding:"required"`
	Note     string `json:"note" binding:"required"`
	Priority string `json:"priority" binding:"required"`
	NoteDate string `json:"note_date" binding:"required"`
}

type UpdateNotesRequest struct {
	Title    string `json:"title" binding:"required"`
	Note     string `json:"note" binding:"required"`
	Priority string `json:"priority" binding:"required"`
	NoteID   int    `json:"note_id" binding:"required"`
}

type NoteRequest struct {
	Year  string `json:"year" binding:"required"`
	Month string `json:"month" binding:"required"`
}

type NoteRequestDay struct {
	Year  string `json:"year" binding:"required"`
	Month string `json:"month" binding:"required"`
	Day   string `json:"day" binding:"required"`
}

type MachineTransactionRequest struct {
	SiteName        string `json:"site_name" binding:"required"`
	PlantName       string `json:"plant_name" binding:"required"`
	DepartementName string `json:"departement_name" binding:"required"`
	WorkCenterName  string `json:"work_center_name" binding:"required"`
	WorkstationName string `json:"workstation_name" binding:"required"`
	TransactionDate string `json:"TransactionDate" binding:"required"`
}
