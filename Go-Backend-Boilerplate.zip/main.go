package main

import "example.com/m/server"

func main() {
	server.Init()
}
