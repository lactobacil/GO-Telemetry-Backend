create table if not exists histories(
	history_id SERIAL primary key,
	country VARCHAR(50),
	value NUMERIC
);

create table if not exists calendar_notes(
	note_id SERIAL primary key,
	title VARCHAR(100),
	note VARCHAR(200),
	priority VARCHAR(4),
	note_date TIMESTAMP
);


INSERT INTO
	histories(country, value)
values
	('Argentina', 1000000),
	('Brazil', 225000),
	('Congo', 32000000),
	('Denmark', 47000000),
	('Ecuador', 5000000),
	('Fiji', 6000000),
	('Germany', 7000000),
	('Honduras', 8000000),
	('Indonesia', 9000000);



create table if not exists user_data(
	id SERIAL primary key,
	username VARCHAR(50),
	job_position VARCHAR(50),
	country VARCHAR(50),
);

create table if not exists machine_utilization(
	id SERIAL primary key,
	status VARCHAR(50),
	timelog TIMESTAMP,
	offline BOOLEAN,
	running BOOLEAN,
	idle BOOLEAN,
	down BOOLEAN,
);
