select id, sfm from sfm where sfm like '%12%';

select id, sfm from sfm where sfm < 'SFM1300'
order by sfm asc;

select site, plant_area, cell_number.cellnumber, work_centre, sfm from site
inner join plant_area on plant_area.site_id = site.id 
inner join cell_number on cell_number.plant_area_id = plant_area.id
inner join work_centre on work_centre.cellnumberid = cell_number.id 
inner join sfm on sfm.work_centre_id  = work_centre.id;

select work_centre,count(work_centre) as total_SFM from work_centre
inner join sfm on sfm.work_centre_id  = work_centre.id 
group by work_centre.work_centre;

select work_centre, sfm.sfm from work_centre
inner join sfm on sfm.work_centre_id  = work_centre.id
where sfm = (select min(s2.sfm) from sfm s2 where s2.work_centre_id  = sfm.work_centre_id)
order by work_centre asc;

select sfm, andon_complain_start_time, andon_complain_finish_time,
case  
	when andon_status = 'OPENED' then 
	CONCAT((
    (DATE_PART('day', now()  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', now() - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', now() - andon_complain_start_time))
    )/1440, ' days')
    else
    CONCAT((
    (DATE_PART('day', andon_complain_finish_time  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', andon_complain_finish_time - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', andon_complain_finish_time - andon_complain_start_time))
    )/1440, ' days')
end andon_day_duration,
case  
	when andon_status = 'OPENED' then 
	CONCAT((
    (DATE_PART('day', now()  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', now() - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', now() - andon_complain_start_time))
    )/60, ' hours')
    else
    CONCAT((
    (DATE_PART('day', andon_complain_finish_time  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', andon_complain_finish_time - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', andon_complain_finish_time - andon_complain_start_time))
    )/60, ' hours')
end andon_hours_duration,
case  
	when andon_status = 'OPENED' then 
	CONCAT((
    (DATE_PART('day', now()  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', now() - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', now() - andon_complain_start_time))
    ), ' minutes')
    else
    CONCAT((
    (DATE_PART('day', andon_complain_finish_time  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', andon_complain_finish_time - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', andon_complain_finish_time - andon_complain_start_time))
    ), ' minutes')
end andon_minutes_duration
from andon_transaction
inner join sfm on andon_transaction.sfm_id = sfm.id;


with query1 as(
select sfm,
case  
	when andon_status = 'OPENED' then 
	CONCAT((
    (DATE_PART('day', now()  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', now() - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', now() - andon_complain_start_time))
    )/1440, ' days')
    else
    CONCAT((
    (DATE_PART('day', andon_complain_finish_time  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', andon_complain_finish_time - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', andon_complain_finish_time - andon_complain_start_time))
    )/1440, ' days')
end andon_day_duration,
case  
	when andon_status = 'OPENED' then 
	CONCAT((
    (DATE_PART('day', now()  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', now() - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', now() - andon_complain_start_time))
    )/60, ' hours')
    else
    CONCAT((
    (DATE_PART('day', andon_complain_finish_time  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', andon_complain_finish_time - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', andon_complain_finish_time - andon_complain_start_time))
    )/60, ' hours')
end andon_hours_duration,
case  
	when andon_status = 'OPENED' then 
	CONCAT((
    (DATE_PART('day', now()  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', now() - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', now() - andon_complain_start_time))
    ), ' minutes')
    else
    CONCAT((
    (DATE_PART('day', andon_complain_finish_time  - andon_complain_start_time) * 1440) + 
    (DATE_PART('hours', andon_complain_finish_time - andon_complain_start_time) * 60) + 
    (DATE_PART('minutes', andon_complain_finish_time - andon_complain_start_time))
    ), ' minutes')
end andon_minutes_duration
from andon_transaction
inner join sfm on andon_transaction.sfm_id = sfm.id
), query_max as ( 
	SELECT DISTINCT ON (q1.sfm)
    q1.sfm, andon_day_duration, andon_hours_duration, andon_minutes_duration, CONCAT('longest') AS status
	from query1 q1
	order by q1.sfm, andon_minutes_duration desc
), query_min as ( 
	SELECT DISTINCT ON (q1.sfm)
    q1.sfm, andon_day_duration, andon_hours_duration, andon_minutes_duration, CONCAT('shortest') AS status
	from query1 q1
	order by q1.sfm, andon_minutes_duration asc 
) 
select qmax.sfm, 
qmax.andon_day_duration,
qmax.andon_hours_duration,
qmax.andon_minutes_duration, 
qmax.status from query_max qmax
union
select qmin.sfm, 
qmin.andon_day_duration, 
qmin.andon_hours_duration,
qmin.andon_minutes_duration,
qmin.status from query_min qmin
order by sfm
